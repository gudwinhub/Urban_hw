
def prnt():
    print('Здравствуй ')

prnt()
verbl = 'word!'